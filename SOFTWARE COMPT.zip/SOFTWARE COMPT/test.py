import smtplib
'''s=smtplib.SMTP('smtp.gmail.com',587)
s.starttls()
em='vikas.jaiswal.17735@ves.ac.in'                                  
msg='msg'
s.login('koushikv333@gmail.com','wvhjtqituxkcrvbh')
s.sendmail('vikas.jaiswal.17735@ves.ac.in',em,msg)
s.quit()


s=smtplib.SMTP('smtp.gmail.com',587)
s.starttls()
x=input("Enter your Email-ID")
em=x                       
msg='hii these mail is send through python'
s.login('koushikv333@gmail.com','wvhjtqituxkcrvbh')
s.sendmail('koushikv333@gmail.com',em,msg)
print("Mail send sucessfully")
s.quit()'''