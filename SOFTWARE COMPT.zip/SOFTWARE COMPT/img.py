from tkinter import *
from PIL import  ImageTk, Image
root =Tk()
root.geometry("1366x768")

frame_image = Frame(root, borderwidth=2, bg="white", relief=SUNKEN)
frame_image.pack(side=TOP, fill="x")


my_image = ImageTk.PhotoImage(Image.open("images.jpg"))
my_image = PhotoImage(frame_image, image=my_image)
my_image.pack()

mainloop()